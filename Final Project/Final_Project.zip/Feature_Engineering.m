clear all;
for T=1:15
    fname='C:\Users\SONY\Downloads\Activity Recognition from Single Chest-Mounted Accelerometer\Activity Recognition from Single Chest-Mounted Accelerometer\';
    fmt='.csv';
    fname=[fname num2str(T) fmt];
data = load (fname);
lable = data(:,5);
accX = data(:,2);%3rd column of the CSV file is the values of Accelerometer X
accY = data(:,3);%4th column of the CSV file is the values of Accelerometer Y
accZ = data(:,4);%5th column of the CSV file is the values of Accelerometer Z
%**************************************************************************
i=1;

[m,n]=size(accX);
acc = ones(1,m);
%%************Initialization of the statistical values of the windows******%

%**************************************************************************
%**************************************************************************
gX=0;
gY=0;
gZ=0;
accXDc=zeros(m, 1);
accYDc=zeros(m, 1);
accZDc=zeros(m, 1);
alpha=0.2;
for i=1:m
    acc(i)=sqrt((accX(i)^2+accY(i)^2+accZ(i)^2));
    gX=(1-alpha)*gX+(alpha*accX(i));
    accXDc(i)=accX(i)-gX;
    gY=(1-alpha)*gY+(alpha*accY(i));
    accYDc(i)=accY(i)-gY;
    gZ=(1-alpha)*gZ+(alpha*accZ(i));
    accZDc(i)=accZ(i)-gZ;
end

i=1;
j=1;
windowsize=50;
%*******In each iteration, statistical values of a window are calculated
%and raw data(accX,accY,accZ) index is inceremented by windowsize/2 to
%provide %50 overlapping*************************************************%
while(i<=m-52)
    
     corrmatrix=corrcoef([accX(i:i+windowsize-1),accY(i:i+windowsize-1),accZ(i:i+windowsize-1)]);
     XYcorr(j)=corrmatrix(1,2);
     XZcorr(j)=corrmatrix(1,3);
     YZcorr(j)=corrmatrix(2,3);
     
     avgX(j)=mean(accX(i:i+windowsize-1));
     stdX(j)=std(accX(i:i+windowsize-1));
     maxX(j)=max(accX(i:i+windowsize-1));
     minX(j)=min(accX(i:i+windowsize-1));
     
     avgY(j)=mean(accY(i:i+windowsize-1));
     stdY(j)=std(accY(i:i+windowsize-1));
     maxY(j)=max(accY(i:i+windowsize-1));
     minY(j)=min(accY(i:i+windowsize-1));
   
     avgZ(j)=mean(accZ(i:i+windowsize-1));
     stdZ(j)=std(accZ(i:i+windowsize-1));
     maxZ(j)=max(accZ(i:i+windowsize-1));
     minZ(j)=min(accZ(i:i+windowsize-1));
     
     avgACC(j)=mean(acc(i:i+windowsize-1));
     stdACC(j)=std(acc(i:i+windowsize-1));
     maxACC(j)=max(acc(i:i+windowsize-1));
     minACC(j)=min(acc(i:i+windowsize-1));
   
     energyX(j)=sum(abs(fft(accX(i:i+windowsize-1))))/windowsize;
     energyY(j)=sum(abs(fft(accY(i:i+windowsize-1))))/windowsize;
     energyZ(j)=sum(abs(fft(accZ(i:i+windowsize-1))))/windowsize;
     
     avgXDc(j)=mean(accXDc(i:i+windowsize-1));
     stdXDc(j)=std(accXDc(i:i+windowsize-1));
     maxXDc(j)=max(accXDc(i:i+windowsize-1));
     minXDc(j)=min(accXDc(i:i+windowsize-1));
     
     avgYDc(j)=mean(accYDc(i:i+windowsize-1));
     stdYDc(j)=std(accYDc(i:i+windowsize-1));
     maxYDc(j)=max(accYDc(i:i+windowsize-1));
     minYDc(j)=min(accYDc(i:i+windowsize-1));
   
     avgZDc(j)=mean(accZDc(i:i+windowsize-1));
     stdZDc(j)=std(accZDc(i:i+windowsize-1));
     maxZDc(j)=max(accZDc(i:i+windowsize-1));
     minZDc(j)=min(accZDc(i:i+windowsize-1));
     
     energy(j)=sum(abs(fft(acc(i:i+windowsize-1))))/windowsize;  %
     
     Y(j) = mode(lable(i:i+windowsize-1));
     %Energy is defined as the normalized summation of absolute values of
     %Discrete Fourier Transform of a windowed signal sequence
     %k=i;
     i=i+windowsize/2-1;
     %System.out.println(k+i);
     %display(k);
     display(i);
     j=j+1;
end
   
   
    cell1=[maxX.',minX.',avgX.',stdX.',maxY.',minY.',avgY.',stdY.',maxZ.',minZ.',avgZ.',stdZ.',maxACC.',minACC.',avgACC.',stdACC.',XYcorr.',XZcorr.',YZcorr.',energy.',avgXDc.',stdXDc.',avgYDc.',stdYDc.',avgZDc.',stdZDc.',Y.'];
    
    %cell=[avgX.',stdX.',avgY.',stdY.',avgZ.',stdZ.',XYcorr.',XZcorr.',YZcorr.',energyX.',energyY.',energyZ.',avgXDc.',stdXDc.',avgYDc.',stdYDc.',avgZDc.',stdZDc.',Y.'];
    
    cell=cell(randperm(length(cell)),:);
    fname='C:\Users\SONY\Downloads\Accelerometer\dc2\features_Dc_';
    fname1=[fname num2str(T) fmt];
    csvwrite(fname1,cell);
end
%dataset=load('C:\Users\SONY\Downloads\Accelerometer\dc\all.csv');
    %dataset=dataset(randperm(length(dataset)),:);
    %csvwrite('C:\Users\SONY\Downloads\Accelerometer\all_1.csv',dataset);
    